import React from 'react';
import './main.styl';

import { RDRender } from './utilities';
import { Calculator } from './components';

RDRender(<Calculator/>);
